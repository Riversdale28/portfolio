#!/bin/bash
 
# Author:  Margot Mills
# Date:  
# Version:  

awk '{print $1}' input.txt
