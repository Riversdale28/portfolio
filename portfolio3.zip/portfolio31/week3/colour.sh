#!/bin/bash
 
# Author:  Margot Mills
# Date:  
# Version:  

echo "Testing colours : " 
 $cols="\033[32m"

 echo "This is the colour : $cols"

