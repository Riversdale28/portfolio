#!/bin/bash
 
# Author:  Margot Mills
# Date:  February 2022
# Version:  1

 for i in Apple Mango Strawberry Orange Banana
 do
    echo "FRUIT:  $i"
 done
 
 
