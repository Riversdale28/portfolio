#!/bin/bash
 
# Author:  Margot Mills
# Date:  
# Version:  

echo " Choose a colour "

echo " 1. Black"
echo " 2. Red "
echo " 3. Green " 
echo " 4. Brown"
echo " 5. Blue"
echo " 6. Purple"
echo " 7. Cyan"
echo " 8. Grey"
echo

read -p 'Choose arithmetic option : ' col_var

case col_var in

{Black} )
# code if match
\033|30m
;;

{Red} )
# code if match
\033|31m
;;

{Green} )
# code if match
\033|32m
;;

{Brown} )
# code if match
\033|33m
;;

{Blue} )
# code if match
\033|34m
;;

{Purple} )
# code if match
\033|35m
;;

{Cyan} )
# code if match
\033|36m
;;

{Grey} )
# code if match
\033|37m
;;

*) default case
# code if default case
;;
esac