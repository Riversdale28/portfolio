#!/usr/bin/python3 

import hashlib
import string
import random

#  The full character set and a 5 char password takes over 1 hour to crack!

chars = string.printable
chars_list = list(chars)

# Test printing of ALL characters from above...
print(chars_list)

# Hidden password is "hello"
passwordHash = "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824"

wordlistHash=''
#function to convert follows

def listToString(s):

    str1 = ""

    for ele in s:

        str1 += ele

    return str1

 

character_list = list(chars_list)
guess_password=''

while (passwordHash != wordlistHash):

    guess_password=random.choices(character_list,k=5)

    print(">>>>>>>>>>>"+str(guess_password)+"<<<<<<<<<")
    print(listToString(guess_password))
    word=listToString(guess_password)
    word = word.rstrip()
    wordlistHash = hashlib.sha256(word.encode("utf-8")).hexdigest()

    if(passwordHash == wordlistHash):

        print("Password has been cracked! It is",guess_password)

        break
