#!/bin/bash
echo "Hi there Margot"
exit 22
