#!/bin/bash
echo "Hi There Margot!"
echo "It's good to see you $1!"
exit 0