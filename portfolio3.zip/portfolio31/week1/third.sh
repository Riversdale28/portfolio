#!/bin/bash 
cowsay "Hi $1 $2"
exit 0