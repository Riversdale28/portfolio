#!/bin/bash
 
# Author:  Margot Mills
# Date:  23 February 2022
# Version:  99

# This script downloads from a website all cyber incidents since 2006, and presents an interactive menu to query the data.
# The top-level site has a link to the data in .pdf file format, so I used pdftotext (installed via sudo apt-get install poppler-utils)
# to convert the .pdf file to a .txt file called incidents.txt

wget https://www.csis.org/programs/strategic-technologies-program/significant-cyber-incidents

# To find reference to the PDF file in HTML - grep returns entire HTML line from the top-level code
grep .pdf significant-cyber-incidents > pdf_ref.txt

# Strip HTML code from the PDF file URL
sed -i 's/^.\{15\}//' pdf_ref.txt
sed -i 's/.\{64\}$//' pdf_ref.txt

xargs -n 1 curl -O < pdf_ref.txt 

# pdftotext command converts PDF to incidents.txt
# code is: pdftotext -layout 220203_Significant_Cyber_Incidents.pdf?6nUHMBGT7zrGtFIeHU4gGdjD7dXFObfO incidents.txt
# pdf_filename.sh contains that code...
./pdf_filename.sh

clear
# ************************************************************************************************************
# Present user with options on how they want to interrogate the data....
echo ""
echo -e "\033[32m"The incidents database contains 9000+ entries for various cybersecurity events"\e[0m"
echo -e "\033[32m"The events are classified by Year, Country and Description of cybersecurity breach,"\e[0m"
echo -e "\033[32m"and covers the years between 2006 and 2022."\e[0m"
echo
echo -e "\033[35m"Select a Cybersecurity Event to view from the following list"\e[0m" 
echo ""

function menu {
PS3="Type number (1-13): "
select i in Ransomware Malware DDoS Hack_attack Trojan_horse Log4j_attacks Email_compromise Social_Media Intelligence_Gathering Backdoor_malware Bots Stolen_credentials Exit 
do
   case $i in
   Ransomware) echo "The number of Ransomware attacks in the database is " 
               grep -i -c 'Ransomware' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Ransomware' -i -A1 -B1 --color=always incidents.txt;;

   Malware) echo "The number of Malware attacks in the database is " 
               grep -i -c 'Malware' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Malware' -i -A1 -B1 --color=always incidents.txt;;
   
   DDoS)       echo "The number of DDoS attacks in the database is " 
               grep -i -c 'DDoS' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'DDoS' -i -A1 -B1 --color=always incidents.txt;;

   Hack_attack) echo "The number of Hack attacks in the database is " 
               grep -i -c 'HacK' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Hack' -i -A1 -B1 --color=always incidents.txt;;

   Trojan_horse) echo "The number of Trojan_horse attacks in the database is " 
               grep -i -c 'Trojan' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Trojan' -i -A1 -B1 --color=always incidents.txt;;

   Log4j_attacks) echo "The number of Log4j_attacks attacks in the database is " 
               grep -i -c 'Log4j' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Log4j' -i -A1 -B1 --color=always incidents.txt;;

   Email_compromise) echo "The number of Email_compromise attacks in the database is " 
               grep -i -c 'Email' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Email' -i -A1 -B1 --color=always incidents.txt;;

   Social_Media) echo "The number of Social_Media and Social Security attacks in the database is " 
               grep -i -c 'Social' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Social' -i -A1 -B1 --color=always incidents.txt;;

   Intelligence_Gathering) echo "The number of Intelligence_Gathering attacks in the database is " 
               grep -i -c 'Intelligence' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Intelligence' -i -A1 -B1 --color=always incidents.txt;;

   Backdoor_malware) echo "The number of Backdoor_malware attacks in the database is " 
               grep -i -c 'Backdoor' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Backdoor' -i -A1 -B1 --color=always incidents.txt;;

   Bots)        echo "The number of Bot attacks in the database is " 
               grep -i -c 'Bots' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Bots' -i -A1 -B1 --color=always incidents.txt;;

   Stolen_credentials) echo "The number of Stolen_credentials attacks in the database is " 
               grep -i -c 'Credential' incidents.txt
               read -p "Press enter to see these attacks in context..."
               grep 'Credential' -i -A1 -B1 --color=always incidents.txt;;

   Exit) exit;;  
   *) echo "Invalid option $REPLY, please try again...";;
     
   esac
echo ""
echo ""
read -p "Press enter to continue... " 
clear
echo "" 
done
}

menu

exit 0
