#!/bin/bash

pdftotext -layout 220203_Significant_Cyber_Incidents.pdf?6nUHMBGT7zrGtFIeHU4gGdjD7dXFObfO incidents.txt

