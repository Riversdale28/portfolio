#!/bin/bash
 
# Author:  Margot Mills
# Date:  
# Version:  

#  Display IP text file into neat columns & rows

echo "Google Server IPs:"

awk 'BEGIN {
    FS=":";  # This sets the field separator to :
    print "_______________________________ "
    print "|\033[35mServer Type\033[0m | \033[35mIP\033[0m             |";
            }

{
 printf ("|\033[32m%-11s\033[0m | \033[32m%-14s\033[0m |\n", $1, $2);
}

    END {
    print("_______________________________");
        }' input.txt 

exit 0
